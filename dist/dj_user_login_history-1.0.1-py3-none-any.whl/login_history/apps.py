from django.apps import AppConfig


class LoginHistoryConfig(AppConfig):
    name = 'login_history'
